export const environment = {
  api: 'http://103.50.212.163:7184/',
  // api: 'https://localhost:7184/',
  //api: 'http://43.231.124.151:2023/',
  
  production: true
};
