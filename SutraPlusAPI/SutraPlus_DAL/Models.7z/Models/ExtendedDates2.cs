﻿using System;
using System.Collections.Generic;

namespace SutraPlus_DAL.Models
{
    public partial class ExtendedDates2
    {
        public int Companyid { get; set; }
        public DateTime TranctDate { get; set; }
    }
}
