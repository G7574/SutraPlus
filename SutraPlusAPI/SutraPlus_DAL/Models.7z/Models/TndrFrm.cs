﻿using System;
using System.Collections.Generic;

namespace SutraPlus_DAL.Models
{
    public partial class TndrFrm
    {
        public long? Fid { get; set; }
        public DateTime? TrDt { get; set; }
        public long? Tp { get; set; }
        public long? Lt { get; set; }
        public long? Bg { get; set; }
        public long SrNo { get; set; }
        public string? Vrt { get; set; }
    }
}
