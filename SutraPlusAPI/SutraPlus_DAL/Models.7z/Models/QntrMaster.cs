﻿using System;
using System.Collections.Generic;

namespace SutraPlus_DAL.Models
{
    public partial class QntrMaster
    {
        public long Id { get; set; }
        public DateTime TrDt { get; set; }
    }
}
