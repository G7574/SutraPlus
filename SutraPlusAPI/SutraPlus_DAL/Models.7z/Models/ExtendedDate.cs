﻿using System;
using System.Collections.Generic;

namespace SutraPlus_DAL.Models
{
    public partial class ExtendedDate
    {
        public int Companyid { get; set; }
        public DateTime TranctDate { get; set; }
    }
}
