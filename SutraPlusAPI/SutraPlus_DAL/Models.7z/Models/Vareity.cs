﻿using System;
using System.Collections.Generic;

namespace SutraPlus_DAL.Models
{
    public partial class Vareity
    {
        public string? VrtNm { get; set; }
    }
}
