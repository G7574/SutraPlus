﻿using System;
using System.Collections.Generic;

namespace SutraPlus_DAL.Models
{
    public partial class TmpDelNote
    {
        public long Fid { get; set; }
        public long Hid { get; set; }
        public long Bags { get; set; }
        public DateTime Dt { get; set; }
    }
}
