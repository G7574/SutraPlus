﻿using System;
using System.Collections.Generic;

namespace SutraPlus_DAL.Models
{
    public partial class Gstquantra
    {
        public int CompanyId { get; set; }
        public DateTime MonthNo { get; set; }
    }
}
