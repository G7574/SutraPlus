﻿using System;
using System.Collections.Generic;

namespace SutraPlus_DAL.Models
{
    public partial class Tmptdslist1
    {
        public int? Fid { get; set; }
        public DateTime? TrDt { get; set; }
        public long? Id { get; set; }
    }
}
