﻿using System;
using System.Collections.Generic;

namespace SutraPlus_DAL.Models
{
    public partial class Loginn
    {
        public string? UNm { get; set; }
        public string? PW { get; set; }
    }
}
