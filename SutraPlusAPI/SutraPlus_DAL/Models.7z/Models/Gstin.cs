﻿using System;
using System.Collections.Generic;

namespace SutraPlus_DAL.Models
{
    public partial class Gstin
    {
        public string? Gstin1 { get; set; }
    }
}
