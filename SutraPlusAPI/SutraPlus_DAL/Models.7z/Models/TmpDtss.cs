﻿using System;
using System.Collections.Generic;

namespace SutraPlus_DAL.Models
{
    public partial class TmpDtss
    {
        public DateTime Fdt { get; set; }
        public DateTime Tdt { get; set; }
        public long Fid { get; set; }
        public long? Wt { get; set; }
    }
}
