﻿using System;
using System.Collections.Generic;

namespace SutraPlus_DAL.Models
{
    public partial class TmpDt
    {
        public long Fid { get; set; }
        public DateTime Dt { get; set; }
    }
}
